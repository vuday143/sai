<h2>Custom KPI For Qlik Sense</h2>
<h3>Features : </h3>
<ol>
  <li>Font Awesome icons Supported</li>
  <li>Custom Title</li>
  <li>Custom Background Color</li>
  <li>Can Replace fa icon with Image or html tags</li>
  <li>Navigate to Diffrent Sheet</li>
</ol>
<img src="./x-kpi2.gif" alt="3nd Version">
<hr>
